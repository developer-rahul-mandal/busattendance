<?php
// অটোমেটিক রিডাইরেক্ট টু লগইন পেজ
header('Location: login.php');
exit();
?>
